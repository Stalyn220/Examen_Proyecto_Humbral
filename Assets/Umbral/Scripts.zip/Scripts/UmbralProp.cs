using UnityEngine;

namespace Umbral
{
    public enum PropKind { Module, Lever, Reactor, Portal, Checkpoint, Hint, GravityZone, Hazard, Door, CircuitSwitch }

    public sealed class UmbralProp : MonoBehaviour
    {
        public PropKind kind;
        public int index;
        [Tooltip("Circuito activado por este interruptor o exigido por esta puerta.")]
        public string circuit;
        public Vector2 checkpointOffset;
        [TextArea] public string message;
        public SpriteRenderer indicator;
        public Collider2D barrier;
        public bool Activated { get; private set; }
        public bool IsInteractive => kind == PropKind.Module || kind == PropKind.Lever || kind == PropKind.Reactor || kind == PropKind.Portal || kind == PropKind.CircuitSwitch;
        public string Prompt
        {
            get
            {
                if (kind == PropKind.CircuitSwitch) return Activated ? "Circuito activado" : "E  ·  Activar " + gameObject.name;
                if (kind == PropKind.Module) return "E  ·  Recuperar módulo " + (index + 1);
                if (kind == PropKind.Lever) return Activated ? "Palanca activada" : "E  ·  Abrir compuerta de control";
                if (kind == PropKind.Reactor) return UmbralGame.Instance.Rescued ? "Reactor estabilizado" : "E  ·  Instalar los tres módulos";
                return UmbralGame.Instance.Rescued ? "E  ·  Cruzar el portal" : "Portal sin energía";
            }
        }

        void Update()
        {
            var game = UmbralGame.Instance;
            if (game == null) return;
            if (kind == PropKind.Door)
            {
                bool open = !string.IsNullOrEmpty(circuit) ? game.HasCircuit(circuit) : index == 0 ? game.Modules[0] : index == 1 ? game.Modules[1] && game.LeverActivated : game.Rescued;
                if (open && !Activated)
                {
                    Activated = true;
                    if (barrier != null) barrier.enabled = false;
                    foreach (var sprite in GetComponentsInChildren<SpriteRenderer>()) sprite.color *= new Color(1, 1, 1, .12f);
                }
            }
            if (kind == PropKind.Module && indicator != null)
            {
                indicator.transform.localPosition = new Vector3(0, Mathf.Sin(Time.time * 3 + index) * .07f, 0);
                indicator.transform.localRotation = Quaternion.Euler(0, 0, Mathf.Sin(Time.time * 2) * 7);
            }
            if (kind == PropKind.Portal && indicator != null)
                indicator.color = game.Rescued ? new Color(.3f, .95f, 1, .8f + .2f * Mathf.Sin(Time.time * 3)) : new Color(.15f, .28f, .4f, .45f);
        }

        public void Interact()
        {
            var game = UmbralGame.Instance;
            if (game.Mode != GameMode.Playing || !IsInteractive) return;
            if (kind == PropKind.CircuitSwitch)
            {
                if (Activated) return;
                Activated = true;
                game.ActivateCircuit(circuit);
                if (indicator != null) indicator.color = new Color(.3f, 1, .75f);
                game.Notify(string.IsNullOrEmpty(message) ? "Circuito activado. La compuerta ya tiene energía." : message, 3);
                game.Sound(1050, .2f, .14f);
            }
            else if (kind == PropKind.Module)
            {
                game.Modules[index] = true;
                game.Notify("MÓDULO " + (index + 1) + "/3 RECUPERADO · " + message, 4);
                game.Sound(1150 + 140 * index, .25f, .16f);
                game.Pulse(transform.position, new Color(.25f, 1, .85f), 2);
                gameObject.SetActive(false);
            }
            else if (kind == PropKind.Lever)
            {
                if (Activated) return;
                Activated = true;
                game.LeverActivated = true;
                if (indicator != null) indicator.color = new Color(.3f, 1, .75f);
                game.Notify(game.Modules[1] ? "Compuerta abierta. El reactor está al otro lado." : "Palanca activa. Falta recuperar el módulo de los conductos.", 4);
                game.Sound(500, .2f, .12f);
            }
            else if (kind == PropKind.Reactor)
            {
                if (game.Rescued) return;
                if (game.ModuleCount < 3) { game.Notify("MARA · La consola necesita los tres módulos. Llevas " + game.ModuleCount + "/3.", 4); return; }
                game.Rescue();
            }
            else if (kind == PropKind.Portal)
            {
                if (!game.Rescued) game.Notify("NEXO · Primero estabiliza el reactor y libera a Mara.", 3);
                else game.Win();
            }
        }

        void OnTriggerEnter2D(Collider2D other)
        {
            var player = other.GetComponent<UmbralPlayer>();
            if (player == null) return;
            if (kind == PropKind.Hazard) player.Respawn(true);
            else if (kind == PropKind.Checkpoint && !Activated)
            {
                Activated = true;
                player.SetCheckpoint((Vector2)transform.position + checkpointOffset);
                if (indicator != null) indicator.color = new Color(.3f, 1, .75f);
            }
            else if (kind == PropKind.Hint && !Activated)
            {
                Activated = true;
                UmbralGame.Instance.Notify(message, 7);
            }
        }
        void OnTriggerStay2D(Collider2D other)
        {
            if (kind != PropKind.Hazard) return;
            var player = other.GetComponent<UmbralPlayer>();
            if (player != null) player.Respawn(true);
        }
    }
}

using UnityEngine;

namespace Umbral
{
    public sealed class UmbralCompanion : MonoBehaviour
    {
        public bool isMara;
        public SpriteRenderer visual;
        public Sprite[] frames;
        public UmbralCharacterDefinition character;
        void Awake()
        {
            if (character == null) return;
            frames = character.frames;
            if (visual != null && frames.Length > 0) { visual.sprite = frames[0]; visual.transform.localScale = Vector3.one * character.visualScale; }
        }
        Vector3 velocity;
        float nextSpark;
        void Update()
        {
            var game = UmbralGame.Instance;
            if (game == null || game.player == null) return;
            if (game.Mode != GameMode.Playing) return;
            if (!isMara)
            {
                var target = game.player.transform.position + new Vector3(game.player.FacingRight ? -1 : 1, 1.1f, 0);
                target.y = Mathf.Clamp(target.y, 1, 6.9f) + Mathf.Sin(Time.time * 2.2f) * .12f;
                transform.position = Vector3.SmoothDamp(transform.position, target, ref velocity, .35f);
            }
            else if (game.Rescued)
            {
                var target = game.maraChannelPoint != null ? game.maraChannelPoint.position : transform.position;
                bool walking = Vector3.Distance(transform.position, target) > .1f;
                transform.position = Vector3.MoveTowards(transform.position, target, Time.deltaTime * 5.5f);
                if (frames != null && frames.Length >= 20)
                    visual.sprite = frames[(walking ? 4 : 0) + Mathf.FloorToInt(Time.time * (walking ? 10 : 6)) % 4];
                if (!walking && Time.time > nextSpark)
                {
                    nextSpark = Time.time + .4f;
                    game.Pulse(transform.position + Vector3.right * .45f, new Color(.8f, .4f, 1, .5f), .5f);
                }
            }
        }
    }
}

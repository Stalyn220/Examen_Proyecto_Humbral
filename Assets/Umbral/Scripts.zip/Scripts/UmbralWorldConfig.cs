using UnityEngine;

namespace Umbral
{
    [CreateAssetMenu(menuName = "Umbral/Configuración del mundo", fileName = "Mundo")]
    public sealed class UmbralWorldConfig : ScriptableObject
    {
        [System.Serializable]
        public struct SectorDefinition
        {
            public string title;
            public float startX;
            public SectorDefinition(string title, float startX) { this.title = title; this.startX = startX; }
        }
        public float minX = -4;
        public float maxX = 222;
        public float cameraY = 4;
        public float minSafeY = -4;
        public float maxSafeY = 13;
        public SectorDefinition[] sectors = new[] {
            new SectorDefinition("DESPERTAR", 0), new SectorDefinition("CONDUCTOS", 32),
            new SectorDefinition("LABORATORIO CRIOGÉNICO", 68), new SectorDefinition("NÚCLEO DE SEGURIDAD", 108),
            new SectorDefinition("REACTOR", 146), new SectorDefinition("HANGAR DE EVACUACIÓN", 184)
        };
        public string SectorAt(float x)
        {
            for (int i = sectors.Length - 1; i >= 0; i--)
                if (x >= sectors[i].startX) return (i + 1).ToString("00") + " / " + sectors[i].title;
            return sectors.Length > 0 ? "01 / " + sectors[0].title : "EXPLORACIÓN";
        }
    }
}

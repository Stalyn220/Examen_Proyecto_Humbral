using UnityEngine;
namespace Umbral
{
    [RequireComponent(typeof(UmbralDamageable))]
    public sealed class UmbralDrone : MonoBehaviour
    {
        public Vector2 left, right;
        public SpriteRenderer eye;
        public float speed = 1.35f;
        public bool Disabled => damageable == null || damageable.Destroyed;
        bool goRight;
        UmbralDamageable damageable;
        void Awake() { damageable = GetComponent<UmbralDamageable>(); }
        void Update()
        {
            if (Disabled || UmbralGame.Instance == null || UmbralGame.Instance.Mode != GameMode.Playing) return;
            var target = goRight ? right : left;
            transform.position = Vector2.MoveTowards(transform.position, target, speed * Time.deltaTime);
            if (Vector2.Distance(transform.position, target) < .03f) goRight = !goRight;
        }
        public void Disable() { if (!Disabled) damageable.Hit(damageable.Health); }
        void OnTriggerStay2D(Collider2D other)
        {
            var player = other.GetComponent<UmbralPlayer>();
            if (!Disabled && player != null) player.Respawn(true);
        }
    }
}

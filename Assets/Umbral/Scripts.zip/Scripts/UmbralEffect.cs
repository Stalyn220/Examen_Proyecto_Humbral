using UnityEngine;

namespace Umbral
{
    public sealed class UmbralEffect : MonoBehaviour
    {
        public float duration = .4f, expansion = 2;
        public Vector3 drift;
        public Sprite[] frames;
        float age;
        SpriteRenderer visual;
        Color initial;
        Vector3 originalScale;
        void Awake()
        {
            visual = GetComponent<SpriteRenderer>();
            initial = visual.color;
            originalScale = transform.localScale;
        }
        void Update()
        {
            age += Time.deltaTime;
            float t = age / duration;
            transform.position += drift * Time.deltaTime;
            transform.localScale = originalScale * (1 + expansion * t);
            visual.color = initial * new Color(1, 1, 1, 1 - t);
            if (frames != null && frames.Length > 0) visual.sprite = frames[Mathf.Min(frames.Length - 1, (int)(t * frames.Length))];
            if (t >= 1) Destroy(gameObject);
        }
    }
}

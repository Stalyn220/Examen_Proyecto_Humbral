using UnityEngine;

namespace Umbral
{
    [CreateAssetMenu(menuName = "Umbral/Definición de personaje", fileName = "NuevoPersonaje")]
    public sealed class UmbralCharacterDefinition : ScriptableObject
    {
        public string displayName = "Leo";
        [Tooltip("20 sprites: Idle 0-3, Walk 4-7, Run 8-11, Jump 12-15, Attack 16-19.")]
        public Sprite[] frames = new Sprite[20];
        [Tooltip("Cuatro fases del pulso; si queda vacío se usa el pulso de la misión.")]
        public Sprite[] pulseFrames;
        public Color energyColor = new Color(.2f, .9f, 1);
        public Vector2 colliderSize = new Vector2(.63f, 1.48f);
        [Range(.25f, 3)] public float visualScale = 1;
    }
}

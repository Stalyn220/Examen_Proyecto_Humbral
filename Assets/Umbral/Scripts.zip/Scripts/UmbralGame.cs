using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

namespace Umbral
{
    public enum GameMode { Title, Playing, Paused, Won }

    public sealed class UmbralGame : MonoBehaviour
    {
        public static UmbralGame Instance { get; private set; }
        public UmbralWorldConfig world;
        public Transform maraChannelPoint;
        public Sprite fragmentSprite;
        public int EnemiesDestroyed { get; set; }
        readonly HashSet<string> circuits = new HashSet<string>();
        UmbralDamageable[] targets;
        public UmbralPlayer player;
        public UmbralCamera cameraRig;
        public Sprite effectRing;
        public Sprite[] pulseFrames;
        public GameMode Mode { get; private set; }
        public bool[] Modules { get; private set; } = new bool[3];
        public bool LeverActivated { get; set; }
        public bool Rescued { get; private set; }
        public int Deaths { get; set; }
        public float Elapsed { get; private set; }
        public int ModuleCount => (Modules[0] ? 1 : 0) + (Modules[1] ? 1 : 0) + (Modules[2] ? 1 : 0);
        public string Sector => world != null ? world.SectorAt(player.transform.position.x) : "EXPLORACIÓN";
        public string Objective => Rescued ? "Cruza el portal junto a Mara" : ModuleCount == 3 ? "Instala los módulos en la consola del reactor" :
            ModuleCount >= 2 && !HasCircuit("cryo") ? "Activa el relé del laboratorio criogénico" :
            ModuleCount >= 2 && !HasCircuit("security") ? "Destruye el generador de seguridad con J" : "Recupera los tres módulos de energía";
        public UmbralProp Nearest { get; private set; }
        UmbralProp[] props;
        string notification;
        float notificationUntil;
        float volume = .45f;
        AudioSource speaker;
        Vector2 sectorScroll;
        GUIStyle body, small, label, heading, title, button, caption;
        readonly Color cyan = new Color(.35f, .94f, 1), violet = new Color(.68f, .5f, 1), orange = new Color(1, .63f, .32f);

        void Awake()
        {
            Instance = this;
            Time.timeScale = 1;
            Mode = GameMode.Title;
            if (world == null) world = ScriptableObject.CreateInstance<UmbralWorldConfig>();
            Application.targetFrameRate = 120;
            Time.fixedDeltaTime = 1f / 60;
            targets = FindObjectsByType<UmbralDamageable>(FindObjectsSortMode.None);
            props = FindObjectsByType<UmbralProp>(FindObjectsSortMode.None);
            speaker = gameObject.AddComponent<AudioSource>();
            speaker.spatialBlend = 0;
            cameraRig.Snap();
            if (!Application.isEditor && System.Array.IndexOf(System.Environment.GetCommandLineArgs(), "-umbral-qa") >= 0)
                gameObject.AddComponent<UmbralCapture>();
        }

        void OnDestroy()
        {
            Time.timeScale = 1;
            if (Instance == this) Instance = null;
        }

        void Update()
        {
            var keys = Keyboard.current;
            if (keys != null)
            {
                if (keys.enterKey.wasPressedThisFrame && Mode == GameMode.Title) StartGame();
                else if (keys.escapeKey.wasPressedThisFrame)
                {
                    if (Mode == GameMode.Playing) Pause(true);
                    else if (Mode == GameMode.Paused) Pause(false);
                }
            }
            Nearest = null;
            if (Mode != GameMode.Playing) return;
            Elapsed += Time.deltaTime;
            float closest = 1.85f;
            foreach (var prop in props)
            {
                if (prop == null || !prop.gameObject.activeInHierarchy || !prop.IsInteractive) continue;
                float distance = Vector2.Distance(prop.transform.position, player.transform.position);
                if (distance < closest) { closest = distance; Nearest = prop; }
            }
        }

        public void StartGame()
        {
            Mode = GameMode.Playing;
            Time.timeScale = 1;
            Notify("NEXO · Leo, ¿me recibes? Mara está atrapada. Recuperemos los tres módulos.", 7);
            Sound(660, .18f, .15f);
        }

        public bool IsGravityZone(Vector2 position)
        {
            if (props == null) return false;
            foreach (var prop in props)
                if (prop.kind == PropKind.GravityZone && prop.GetComponent<Collider2D>().OverlapPoint(position)) return true;
            return false;
        }

        public void Pause(bool paused)
        {
            Mode = paused ? GameMode.Paused : GameMode.Playing;
            Time.timeScale = paused ? 0 : 1;
        }

        public void TryInteract()
        {
            if (Mode != GameMode.Playing) return;
            // Recompute immediately so pressing E on the first frame in range works too.
            UmbralProp nearest = null;
            float distance = 1.85f;
            foreach (var prop in props)
            {
                if (prop == null || !prop.gameObject.activeInHierarchy || !prop.IsInteractive) continue;
                float candidate = Vector2.Distance(prop.transform.position, player.transform.position);
                if (candidate < distance) { distance = candidate; nearest = prop; }
            }
            if (nearest != null) nearest.Interact();
            else Notify("Acércate a un módulo, una palanca o una terminal para usar E.", 2);
        }

        public void Rescue()
        {
            if (ModuleCount < 3) return;
            Rescued = true;
            Notify("MARA · ¡Funcionó! La barrera está desactivada. Estabilizaré el portal. ¡Vamos!", 8);
            Sound(1400, .5f, .18f);
            var mara = FindObjectsByType<UmbralCompanion>(FindObjectsSortMode.None);
            foreach (var ally in mara) if (ally.isMara) Pulse(ally.transform.position + Vector3.up, violet, 3);
        }

        public void Win()
        {
            if (!Rescued) return;
            Mode = GameMode.Won;
            player.Body.linearVelocity = Vector2.zero;
            Time.timeScale = 0;
            Sound(1650, .6f, .15f);
        }

        public void Notify(string text, float seconds)
        {
            notification = text;
            notificationUntil = Time.unscaledTime + seconds;
        }

        public void Sound(float frequency, float duration, float gain)
        {
            if (speaker == null || volume < .01f) return;
            int count = Mathf.CeilToInt(22050 * duration);
            var samples = new float[count];
            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                samples[i] = Mathf.Sin(i * frequency / 22050 * Mathf.PI * 2 * (1 - t * .25f)) * Mathf.Sin(t * Mathf.PI) * gain;
            }
            var clip = AudioClip.Create("Umbral / señal", count, 1, 22050, false);
            clip.SetData(samples, 0);
            speaker.PlayOneShot(clip, volume);
            Destroy(clip, duration + .25f);
        }

        public void Pulse(Vector3 position, Color color, float size)
        {
            var obj = new GameObject("Destello de energía");
            obj.transform.position = position;
            obj.transform.localScale = Vector3.one * size;
            var renderer = obj.AddComponent<SpriteRenderer>();
            renderer.sprite = effectRing;
            renderer.color = color;
            renderer.sortingOrder = 25;
            obj.AddComponent<UmbralEffect>();
        }

        public bool HasCircuit(string circuit) => !string.IsNullOrEmpty(circuit) && circuits.Contains(circuit);
        public void ActivateCircuit(string circuit)
        {
            if (!string.IsNullOrEmpty(circuit)) circuits.Add(circuit);
        }
        public void Explosion(Vector3 position, Color color, float size)
        {
            Pulse(position, color, size);
            for (int i = 0; i < 8; i++)
            {
                var obj = new GameObject("Fragmento de explosión");
                obj.transform.position = position;
                obj.transform.localScale = Vector3.one * Random.Range(.06f, .13f);
                var sprite = obj.AddComponent<SpriteRenderer>();
                sprite.sprite = fragmentSprite;
                sprite.color = i % 2 == 0 ? color : Color.white;
                sprite.sortingOrder = 24;
                float angle = i * Mathf.PI / 4;
                var effect = obj.AddComponent<UmbralEffect>();
                effect.duration = .35f;
                effect.expansion = -.6f;
                effect.drift = new Vector3(Mathf.Cos(angle), Mathf.Sin(angle), 0) * Random.Range(2, 4);
            }
        }
        public void Shot(Vector2 position, bool right, int gravity, UmbralMovementSettings balance, UmbralCharacterDefinition character)
        {
            var obj = new GameObject("Proyectil de energía");
            obj.transform.position = position;
            obj.transform.localScale = new Vector3(right ? 1 : -1, gravity, 1) * .85f;
            var frames = character != null && character.pulseFrames != null && character.pulseFrames.Length > 0 ? character.pulseFrames : pulseFrames;
            var renderer = obj.AddComponent<SpriteRenderer>();
            renderer.sprite = frames[0];
            renderer.sortingOrder = 23;
            var projectile = obj.AddComponent<UmbralProjectile>();
            projectile.frames = frames;
            projectile.speed = balance.projectileSpeed;
            projectile.range = balance.projectileRange;
            projectile.damage = balance.damage;
            projectile.right = right;
            Pulse(position, character != null ? character.energyColor : cyan, .3f);
        }

        void Styles()
        {
            if (body != null) return;
            var font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            body = new GUIStyle { font = font, fontSize = 24, wordWrap = true, normal = { textColor = new Color(.82f, .88f, .95f) } };
            small = new GUIStyle(body) { fontSize = 18 };
            label = new GUIStyle(body) { fontSize = 19, fontStyle = FontStyle.Bold, normal = { textColor = cyan } };
            heading = new GUIStyle(body) { fontSize = 42, fontStyle = FontStyle.Bold, normal = { textColor = Color.white } };
            title = new GUIStyle(heading) { fontSize = 118 };
            caption = new GUIStyle(small) { fontSize = 16, normal = { textColor = new Color(.51f, .64f, .76f) } };
            button = new GUIStyle(GUI.skin.button) { font = font, fontSize = 23, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
        }

        void Box(Rect r, Color color)
        {
            GUI.color = color;
            GUI.DrawTexture(r, Texture2D.whiteTexture);
            GUI.color = Color.white;
        }
        void Panel(Rect r, Color accent)
        {
            Box(r, new Color(.025f, .045f, .085f, .94f));
            Box(new Rect(r.x, r.y, 3, r.height), accent);
        }
        bool Button(Rect r, string text, bool primary = false)
        {
            GUI.backgroundColor = primary ? new Color(.13f, .55f, .65f) : new Color(.12f, .18f, .28f);
            bool result = GUI.Button(r, text, button);
            GUI.backgroundColor = Color.white;
            return result;
        }

        void OnGUI()
        {
            Styles();
            GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(Screen.width / 1600f, Screen.height / 900f, 1));
            if (Mode == GameMode.Title) { DrawTitle(); return; }
            Panel(new Rect(24, 20, 430, 86), cyan);
            GUI.Label(new Rect(44, 31, 390, 27), Sector, label);
            GUI.Label(new Rect(44, 66, 400, 25), "UMBRAL · ESTACIÓN DE INVESTIGACIÓN", caption);
            Panel(new Rect(470, 20, 735, 86), violet);
            GUI.Label(new Rect(492, 31, 690, 25), "OBJETIVO ACTUAL", caption);
            GUI.Label(new Rect(492, 61, 690, 34), Objective, small);
            Panel(new Rect(1220, 20, 356, 86), orange);
            GUI.Label(new Rect(1240, 31, 310, 28), "ENERGÍA  " + ModuleCount + " / 3", label);
            for (int i = 0; i < 3; i++) Box(new Rect(1242 + i * 55, 74, 43, 7), Modules[i] ? cyan : new Color(.16f, .24f, .32f));
            GUI.Label(new Rect(1430, 65, 140, 24), "GRAV. " + (player.GravitySign == 1 ? "↓" : "↑"), small);

            if (Mode == GameMode.Playing && Nearest != null)
            {
                var screen = Camera.main.WorldToScreenPoint(player.transform.position + Vector3.up * 1.25f);
                float x = Mathf.Clamp(screen.x / Screen.width * 1600 - 185, 20, 1210);
                float y = Mathf.Clamp(900 - screen.y / Screen.height * 900, 135, 700);
                Panel(new Rect(x, y, 370, 42), cyan);
                GUI.Label(new Rect(x + 12, y + 10, 350, 30), Nearest.Prompt, small);
            }
            if (Time.unscaledTime < notificationUntil && Mode == GameMode.Playing)
            {
                Panel(new Rect(250, 788, 1100, 60), violet);
                GUI.Label(new Rect(272, 803, 1056, 48), notification, small);
            }
            Box(new Rect(0, 861, 1600, 39), new Color(.025f, .035f, .06f, .98f));
            GUI.Label(new Rect(28, 871, 1400, 26), "A/D  MOVER     SHIFT  CORRER     ESPACIO  SALTAR     Q  GRAVEDAD     J  PULSO     E  INTERACTUAR     R  VOLVER A BALIZA     ESC  PAUSA", caption);
            if (Mode == GameMode.Playing && player.InGravityZone)
            {
                GUI.Label(new Rect(30, 155, 530, 30), "ZONA DE GRAVEDAD  /  Q PARA INVERTIR", label);
            }
            if (Mode == GameMode.Playing)
            {
                GUI.Label(new Rect(30, 123, 630, 30), "J  MANTENER PARA DISPARAR  /  " + (player.AttackReady >= .99f ? "PULSO LISTO" : "RECARGANDO") + "  /  ENEMIGOS " + EnemiesDestroyed, small);
                if (targets != null) foreach (var target in targets)
                {
                    if (target == null || target.Destroyed || target.maxHealth < 2) continue;
                    var point = Camera.main.WorldToScreenPoint(target.transform.position + Vector3.up * .65f);
                    if (point.z < 0 || point.x < 0 || point.x > Screen.width) continue;
                    float x = point.x / Screen.width * 1600 - 34, y = 900 - point.y / Screen.height * 900;
                    Box(new Rect(x, y, 68, 7), new Color(.1f, .1f, .15f));
                    Box(new Rect(x, y, 68f * target.Health / target.maxHealth, 7), orange);
                }
            }
            if (Mode == GameMode.Paused) DrawPause();
            if (Mode == GameMode.Won) DrawEnding();
        }

        void DrawTitle()
        {
            Box(new Rect(0, 0, 1600, 900), new Color(.015f, .025f, .055f, .80f));
            Box(new Rect(80, 114, 60, 5), cyan);
            GUI.Label(new Rect(80, 150, 850, 40), "PROYECTO", label);
            GUI.Label(new Rect(73, 179, 1000, 145), "UMBRAL", title);
            GUI.Label(new Rect(83, 344, 750, 48), "El suelo ya no es tu única salida.", heading);
            GUI.Label(new Rect(84, 426, 720, 140), "El reactor ha colapsado. Mara sigue atrapada.\nCon Nexo a tu lado, cambia la gravedad, recupera\nlos tres módulos y encuentra una salida.", body);
            if (Button(new Rect(84, 618, 355, 65), "INICIAR MISIÓN   /   ENTER", true)) StartGame();
            if (Button(new Rect(456, 618, 210, 65), "SALIR")) Application.Quit();
            Panel(new Rect(1000, 160, 500, 570), violet);
            GUI.Label(new Rect(1032, 192, 440, 34), (world != null ? world.sectors.Length.ToString() : "0") + " SECTORES · UNA MISIÓN", label);
            var descriptions = new[] { "Aprende a recorrer suelo y techo.", "Cruza los fosos de mantenimiento.", "Activa el relé de refrigeración.", "Destruye el generador de bloqueo.", "Reúne los módulos y libera a Mara.", "Protege la salida y cruza el portal." };
            int sectorCount = world != null ? world.sectors.Length : 0;
            sectorScroll = GUI.BeginScrollView(new Rect(1024, 240, 460, 470), sectorScroll, new Rect(0, 0, 435, Mathf.Max(465, sectorCount * 76)), false, false);
            for (int i = 0; i < sectorCount; i++)
            {
                GUI.Label(new Rect(8, 8 + i * 76, 422, 30), (i + 1).ToString("00") + "  " + world.sectors[i].title, small);
                GUI.Label(new Rect(8, 38 + i * 76, 422, 28), i < descriptions.Length ? descriptions[i] : "Continúa explorando la estación.", caption);
            }
            GUI.EndScrollView();
            GUI.Label(new Rect(84, 796, 1250, 45), "PLATAFORMAS + PUZLES + COMBATE  /  UN JUGADOR  /  TECLADO  /  EXPLORACIÓN", caption);
            GUI.Label(new Rect(84, 848, 1250, 28), "Stalyn Quispe · Proyecto académico · Prototipo jugable", caption);
        }

        void DrawPause()
        {
            Box(new Rect(0, 0, 1600, 900), new Color(.01f, .02f, .04f, .86f));
            Panel(new Rect(460, 190, 680, 540), cyan);
            GUI.Label(new Rect(510, 230, 590, 60), "MISIÓN EN PAUSA", heading);
            GUI.Label(new Rect(510, 309, 580, 65), "Módulos " + ModuleCount + "/3  ·  Reinicios " + Deaths + "\nTu progreso se conserva durante esta partida.", small);
            GUI.Label(new Rect(510, 395, 580, 30), "VOLUMEN", label);
            volume = GUI.HorizontalSlider(new Rect(510, 440, 580, 30), volume, 0, 1);
            if (Button(new Rect(510, 495, 580, 55), "CONTINUAR", true)) Pause(false);
            if (Button(new Rect(510, 565, 580, 55), "REINICIAR MISIÓN")) Restart();
            if (Button(new Rect(510, 635, 580, 55), "SALIR")) Application.Quit();
        }

        void DrawEnding()
        {
            Box(new Rect(0, 0, 1600, 900), new Color(.015f, .025f, .06f, .94f));
            Box(new Rect(170, 150, 80, 5), violet);
            GUI.Label(new Rect(170, 190, 1300, 70), "AL OTRO LADO DEL UMBRAL", heading);
            GUI.Label(new Rect(170, 310, 1150, 195), "Leo, Mara y Nexo logran cruzar.\n\nFrente a ellos, los restos de la estación flotan bajo un cielo desconocido.\nMara observa el horizonte: «La anomalía no termina aquí».\nLo que comenzó en el reactor se extiende por toda la galaxia.", body);
            GUI.Label(new Rect(170, 565, 1200, 45), "MISIÓN COMPLETADA   /   3 MÓDULOS   /   MARA A SALVO", label);
            GUI.Label(new Rect(170, 615, 1200, 40), "Tiempo: " + Mathf.FloorToInt(Elapsed / 60) + " min " + Mathf.FloorToInt(Elapsed % 60) + " s     ·     Reinicios: " + Deaths + "     ·     Enemigos: " + EnemiesDestroyed, body);
            if (Button(new Rect(170, 715, 360, 60), "VOLVER A JUGAR", true)) Restart();
            if (Button(new Rect(550, 715, 220, 60), "SALIR")) Application.Quit();
        }
        void Restart()
        {
            Time.timeScale = 1;
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }
}
